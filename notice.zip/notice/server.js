// templet
const { response } = require('express');
const express = require('express');
const app = express();

app.listen(8080, ()=>{
    // 접속 후 실행 될 구역, 즉 서버오픈
    console.log('8080포트로 접속 됨, 이것은 서버쪽 console');
    
    
    // '/pet'로 접속하면 '펫 페이지 입니다.' 응답하라
    app.get('/pet', (요청, 응답)=>{
        응답.send('펫 페이지입니다.');
    });

    // '/beauty'로 접속하면 '뷰티 페이지 입니다.' 응답하라
    app.get('/beauty', (요청, 응답)=>{
        응답.send('뷰티 페이지입니다.');
    });

    // '/'로(즉, root) 접속하면 index.html 파일을 제공 응답
    app.get('/', (요청, 응답)=>{
        응답.sendFile(__dirname + '/index.html');
    });


});


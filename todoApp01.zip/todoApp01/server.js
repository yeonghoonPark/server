// express 서버
const express = require('express');
const app = express();
// body-parser
app.use(express.urlencoded({extended:true}));
app.use(express.json());

// method-override => delete put method 사용할 수 있게 하는 모듈
const methodOverride = require('method-override')
app.use(methodOverride('_method'));

//mongoDB
const MongoClient = require('mongodb').MongoClient;

// EJS
app.set('view engine','ejs');
// 앱에 전처리 번역기로 ejs를 사용하겠다.



// 데이터베이스 접근
let todoAppDBUrl='mongodb+srv://admin:qwer1234@cluster0.l0kjr.mongodb.net/todoappDB?retryWrites=true&w=majority';
let todoAppDB;
MongoClient.connect(todoAppDBUrl,(err,result)=>{
  if(err) return console.log('db접근 오류');  
  todoAppDB=result.db('todoappDB');  
  
  //서버오픈
  app.listen(8080,()=>{
    console.log('8080포트가 열렸습니다.');
    
  })
});

// '/write'로 접속시 write.html 보내주자
app.get('/write',(req,res)=>{
  res.render('write.ejs')
})

// '/delete'로 접속시 delete.html 보내주자
app.delete('/delete', (req, res) => {
  req.body._id=parseInt(req.body._id)
  todoAppDB.collection('todoapp').deleteOne({_id:req.body._id},(err,result)=>{
  if(err) return console.log('삭제오류');
  console.log(typeof req.body._id)
  res.status(200)
  })  
})

// '/update'로 접속시 update.html 보내주자
app.get('/update/:id',(req,res)=>{
  todoAppDB.collection('todoapp').findOne({_id:Number(req.params.id)},(err,result)=>{
    res.render('update.ejs',{결과:result})
  })  
})

// /put로 접속시 자료 수정하고 시작페이지로 이동
app.put('/put',(req,res)=>{ 
  todoAppDB.collection('todoapp').updateOne({_id:Number(req.body.id)},{$set:{title:req.body.title,order:Number(req.body.order)}},(err,result)=>{
    // 데이터베이스 변경
    if(err) return console.loe('업데이트 실패');    
    // 시작페이지로 이동
    res.redirect('/')
  })  
})




//app으로부터 넘어오는 POST 자료를 받아서 접속된 DB의 컬랙션에 기록하자
app.post('/add',(req,res)=>{
  let appTitle = req.body.title;
  let appOrder = parseInt(req.body.order);  
  // 발행자료 갯수
  todoAppDB.collection('postcount').findOne({개시물갯수:'개시물갯수'},(err,result)=>{
    if(err) return console.log('개시물갯수검색 실패');    
    let totalCount = result.전체갯수;
    //todoapp 자료저장
    todoAppDB.collection('todoapp').insertOne({title:appTitle,order:appOrder,_id:totalCount+1},(err,result)=>{
      if(err) return console.log('/add 오류');
      console.log('/add 성공');
      todoAppDB.collection('postcount').updateOne({개시물갯수:'개시물갯수'},{$inc:{전체갯수:1}},(err,result)=>{
        if(err) return console.log('/add 문서갯수 변경오류');
        res.redirect('/');
      })
    })
  });  
})


// '/'로 접근하는 앱에게 db자료전체를 찾아서 index.ejs에게 제공하자
// let findResult;
app.get('/',(req,res)=>{
  todoAppDB.collection('todoapp').find().toArray((err,result)=>{
    if(err)  return console.log('자료검색 오류');
    res.render('index.ejs',{todoData:result});    
  });  
})
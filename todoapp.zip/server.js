// express
const express = require('express');
const app = express();
// express의 bodyparser middlewear
app.use(express.urlencoded({extended:true}));
app.use(express.json());

// ejs (앱에 전처리,즉 먼저 번역해서 번역기로 ejs를 하용하겠다. 라는 의미)
app.set('view engine', 'ejs');

// mongoDB
const MongoClient = require('mongodb').MongoClient;


let todoAppDbUrl = 'mongodb+srv://admin:qwer1234@cluster0.pi799.mongodb.net/todoappDB?retryWrites=true&w=majority';
let todoAppDB;

// DB 접근
MongoClient.connect(todoAppDbUrl, (error, result)=>{
    if(error){
        return(
            console.log(error)
        );
    }
    todoAppDB = result.db('todoappDB');
    

    // server open, DB접근 안에서 하는 이유는 db연동이 목적이기 때문에 연동 후에 서버가 오픈되는 것이 논리적으로 맞다, 밖에 있어도 상관은 없다.
    app.listen(8080, ()=>{
        console.log('port opened successfully');
    });
});


/*
app.get('/', (require, response)=>{
    response.send('index입니다');
    console.log('응답완료');
});

'/pet'로 접속하면 '고양이 사세요'를 app에 전송하라
app.get('/pet', (require, response)=>{
    response.send('고양이 사세요');
    console.log('응답완료');
});
*/

/*
// '/'로 접속시 index를 전송하라
app.get('/', (require, response)=>{
    response.sendFile(__dirname + '/index.html');
});
*/

// '/write'로 접속시 write를 전송하라
app.get('/write', (require, response)=>{
    response.sendFile(__dirname + '/write.html');
});

// '/delete'로 접속시 delete를 전송하라
app.get('/delete', (require, response)=>{
    response.sendFile(__dirname + '/delete.html');
});

// '/update'로 접속시 update를 전송하라
app.get('/update', (require, response)=>{
    response.sendFile(__dirname + '/update.html');
});

// app으로부터 넘어오는 post자료를 받아서 mongodb의 클라이언트에 전송하고 기록하자, (post는 꼭 response를 해줘야 다운되지 않는다.)
app.post('/add', (require, response)=>{
    let appTitle = require.body.title;
    let appOrder = parseInt(require.body.order);

    // 발행자료 갯수
    todoAppDB.collection('postcount').findOne({게시물갯수:'게시물갯수'}, (error, result)=>{
        if(error){
            return(
                console.log('게시물갯수 검색 실패')
            );
        }
        
        let totalCount = result.전체갯수;

         // todoApp에 자료저장
        todoAppDB.collection('todoapp').insertOne({title:appTitle, order:appOrder, _id:totalCount+1}, (error, result)=>{
            if(error){
                return(
                    console.log('add 오류')
                );
            }
            console.log('save successfully');
            todoAppDB.collection('postcount').updateOne({게시물갯수:'게시물갯수'}, {$inc:{전체갯수:1}}, (error, result)=>{
                if(error){
                    return(
                        console.log('add 문서갯수 변경 오류')
                    );
                }
            });
        });
    });
    // 응답으로 '/'로 리다이렉트
    response.redirect('/write');
});


// /로 접근하는 앱에게 db자료를 찾아서 index.ejs에게 제공하자, render이 오류없이 실행되려면 반드시 views폴더를 생성하고 ejs파일이 위치해야 함.
let findResult;
app.get('/', (require, response)=>{
    todoAppDB.collection('todoapp').find().toArray((error, result)=>{
        if(error){
            return(
                console.log('find 오류')
            );
        }
        findResult = result;
    });
    // render는 경로가 들어가지 않고 파일명만 들어간다.
    response.render('index.ejs', {todoData:findResult});
});
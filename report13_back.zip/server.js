// express
const express = require('express');
const req = require('express/lib/request');
const app = express();
// bodyparser
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// ejs
app.set('view engine', 'ejs');

// middlewear
app.use(express.static(__dirname + '/build'));

// server open
app.listen(8080, () => {
    console.log('port opened success');
})


// '/' = index.html
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
})

// '/blog' render
app.get('/blog', (req, res) => {
    res.render('blog.ejs');
})
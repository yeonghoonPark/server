// express module
const express = require('express');
const app = express();

// mongodb module
const MongoClient = require('mongodb').MongoClient;

// body-parser middlewear 생성 module
app.use(express.json());
app.use(express.urlencoded({extended:true}));


let scheduleDB;

// mongodb의 클라우드에 접속하기(커넥트하기)
MongoClient.connect('mongodb+srv://admin:qwer1234@cluster0.pi799.mongodb.net/schedule?retryWrites=true&w=majority', (error, client)=>{
    if(error){
        return(
            console.log('데이터베이스 오류, 관리자에게 문의하세요')
        );
    }
    scheduleDB = client.db('schedule');

    // server오픈 (클라우드 접속안에 server오픈을 넣는 이유는 데이타베이스가 오류없는 상황에서 서버를 오픈하기 위해?)
    app.listen(8080, ()=>{
        console.log('8080포트 서버오픈');
    });
});


// index.html 파일로드
app.get('/', (require, respons)=>{
    console.log(require.body);
    respons.sendFile(__dirname + '/index.html');
});

// write.html 파일로드
app.get('/write',(요청, 반응)=>{
    console.log(요청.body);
    반응.sendFile(__dirname + '/write.html');
});


// write에서 자료를 서버로 post하기(가져오기), 그리고 mongodb에 저장하기
app.post('/add', (req, res)=>{
    scheduleDB.collection('today').insertOne(
        {
            title:req.body.title, 
            order:req.body.order
        }, (err, result)=>{
        if(err){
            return(
                console.log('오류입니다.')
            );
        }
    });
    // post는 res로 뭐라도 보내줘야 다운이 안된다
    // res.send('저장 완료');
    res.sendFile(__dirname + '/index.html');
});





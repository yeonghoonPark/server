// express 준비
const express = require('express');
const app = express();

// express bodyparser 준비
app.use(express.urlencoded({extended:true}));
app.use(express.json());

//ejs
app.set('view engine', 'ejs');

// mongoDB 준비
const MongoClient = require('mongodb').MongoClient;
// 도메인 변수선언
let DBAddress = 'mongodb+srv://admin:qwer1234@cluster0.pi799.mongodb.net/todoappDB?retryWrites=true&w=majority';
// 결과값으로 받을 변수선언
let todoAppDB;

// mongoDB 연동 준비
MongoClient.connect(DBAddress, (error, result)=>{
    if(error){
        return(
            console.log('DB connection error')
        );
    }
    todoAppDB = result.db('todoappDB');


    // server open, server open을 DB접속안에 넣는 이유는 DB접속이 안되면 server가 오픈되도 의미가 없다, DB접속 안에 속해있는 것이 논리적.
    app.listen(8080, ()=>{
        console.log('port opened success');
    })
    console.log('DB connection success');
    
})


// index.ejs 렌더링, DB에서 가져오기
app.get('/', (req, res)=>{
    todoAppDB.collection('todoapp').find().toArray((error, result)=>{
        if(error){
            return(
                console.log('자료 가져오기 오류')
            )
        }
        res.render('index.ejs', {todoData:result});
    })
    
})

// write.ejs 렌더링 
app.get('/write', (req, res)=>{
    res.render('write.ejs');
})

// write.ejs 에서 저장
app.post('/add', (req, res)=>{
    todoAppDB.collection('todoapp').insertOne({title:req.body.title, order:req.body.order}, (err, result)=>{
        if(err){
            return(
                console.log('client에서 server로 저장오류')
            )
        }
        console.log(req.body);
    });

    res.redirect('/');
})

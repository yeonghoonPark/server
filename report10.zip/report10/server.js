// express
const express = require('express');
const app = express();
// bodyparser
app.use(express.urlencoded({extended:true}));
app.use(express.json());

// ejs
app.set('view engine','ejs');

app.listen(8080, ()=>{
    console.log('8080port opened success');
})

// '/'로 index.ejs
app.get('/', (req, res)=>{
    res.render('index.ejs');
})

// '/insert'로 insert.ejs
app.get('/insert', (req, res)=>{
    res.render('insert.ejs');
})
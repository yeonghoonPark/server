// express로 서버개체 생성
const express = require('express');
const app = express();

// body-parser 라는 middlwear, 현재는 내장형으로 이용, 중요한 것만(body만) 추출해내는 메서드
app.use(express.json());
app.use(express.urlencoded({extended:true}));

// mongodb생성
const MongoClient = require('mongodb').MongoClient;

let activeDB;

// db접속
MongoClient.connect('mongodb+srv://admin:qwer1234@cluster0.pi799.mongodb.net/list?retryWrites=true&w=majority', (error, client)=>{
    if(error){return (
        console.log('데이터베이스 오류, 관리자에게 문의하세요.')
        );
    }

    activeDB = client.db('list');
    
    // server open
    app.listen(8080, ()=>{
        console.log('8080포트 오픈');
        });
    
});




// index.html 파일 로드
app.get('/', (요청, 응답)=>{
    응답.sendFile(__dirname + '/index.html');
});

// 누군가가 '/write' 로 접속하면 'write.html'을 응답하라
app.get('/write', (요청, 응답)=>{
    응답.sendFile(__dirname + '/write.html');
});

// 누군가가 '/add'로 접속하면 입력폼의 자료 2개(title, date)를 서버로 가져와서 list라는 db에 list라는 collection(table)으로 저장하라
app.post('/add', (요청, 응답)=>{
    activeDB.collection('list').insertOne({title:요청.body.title, date:요청.body.date},(error, result)=>{
        if(error){return (
            console.log('저장 실패')
            )
        ;}
        console.log('저장 완료');
    });
    응답.send('전송 완료')
});

const express = require('express');
const { send } = require('express/lib/response');
const app = express();

app.listen(3000, ()=>{
    console.log('3000포트 서버 오픈.')

    app.get('/read', (req, res)=>{
        res.send('용청의 응답 결과입니다.');
    });

});